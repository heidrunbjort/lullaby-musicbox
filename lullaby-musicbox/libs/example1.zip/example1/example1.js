

// http://10.201.96.138:8888

window.onload = function (event) {
    
    // Some variables we will be using later
    var camera, scene, renderer;
    var controls;
    var element, container;
    
    // A clock to keep track of time in a convenient way
    var clock = new THREE.Clock();
    
    // Initialize the scene, cameras, objects
    init();
    
    // Start animating (updates and render)
    animate();

    function init () {
        
        // Create render, append canvas to the DOM
        renderer = new THREE.WebGLRenderer({ antialias: true, });
        element = renderer.domElement;
        container = document.getElementById('container');
        container.appendChild(element);
        
        // Create scene
        scene = new THREE.Scene();
        scene.background = new THREE.Color(0x000000);
        
        // Create camera and position it in space
        camera = new THREE.PerspectiveCamera(90, window.innerWidth / window.innerHeight, 0.01, 1000);
        camera.position.set(0, 150, 150);
        scene.add(camera);
        
        // Allows navigating the scene via mouse
        controls = new THREE.OrbitControls(camera, element);
        
        // Add the cube
        var cubeGeometry = new THREE.CubeGeometry(100, 100, 100);
        var cubeMaterial = new THREE.MeshNormalMaterial();
        cube = new THREE.Mesh(cubeGeometry, cubeMaterial);
        scene.add(cube);
        
        // Adjust everything in case there is a window resize
        window.addEventListener('resize', handleResize);
        // Set up these adjustments for the first time right away
        setTimeout(handleResize, 1);
        
    }

    // Update whatever changed in this iteration:
    // object angles, camera movement, controls 
    // positioning, screen size, etc.
    function update(timeDelta) {
        camera.updateProjectionMatrix();
        controls.update(timeDelta);
    }

    // Make things move a bit in this iteration
    function render() {
        renderer.render(scene, camera);
    }

    // Keep the loop happening (60fps)
    function animate(t) {
        requestAnimationFrame(animate);
        update(clock.getDelta());
        render();
    }

    // Adjust sizes on window resize
    function handleResize() {
        var width = container.offsetWidth;
        var height = container.offsetHeight;
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
        renderer.setSize(width, height);
    }

    // Go fullscreen (different triggers for different browser)
    function switchToFullscreen() {
        if (container.requestFullscreen) {
            container.requestFullscreen();
        }
        else if (container.msRequestFullscreen) {
            container.msRequestFullscreen();
        }
        else if (container.mozRequestFullScreen) {
            container.mozRequestFullScreen();
        }
        else if (container.webkitRequestFullscreen) {
            container.webkitRequestFullscreen();
        }
    }
    
}